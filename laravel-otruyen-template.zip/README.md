# Laravel OTruyen 📚

Gói mở rộng Laravel để thu thập dữ liệu truyện từ API https://otruyenapi.com

## Cài đặt

```bash
composer require your-vendor/laravel-otruyen
```

## Lệnh artisan

```bash
php artisan otruyen:fetch-home --store
php artisan otruyen:fetch-list truyen-moi --page=1 --store
php artisan otruyen:fetch-comic zenbu-kimi-no-sei --store --with-chapters
```

## Tài liệu đầy đủ

> Mở rộng trong thư mục `src/` theo PSR-4: `YourVendor\Otruyen\` với các command, job, facade, model, service provider v.v.
